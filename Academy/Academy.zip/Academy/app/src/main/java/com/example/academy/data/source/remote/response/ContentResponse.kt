package com.example.academy.data.source.remote.response

data class ContentResponse(
    var moduleId: String,
    var content: String
)