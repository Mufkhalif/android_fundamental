package com.example.academy.data

data class ContentEntity(
    var content: String?
)